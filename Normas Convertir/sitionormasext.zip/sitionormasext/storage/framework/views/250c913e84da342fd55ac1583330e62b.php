<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
    <body>
        <a href="<?php echo e(route('exportar.sql')); ?>" class="btn btn-success">Exportar a SQL</a>

        <div class="all-form"> 
            <div class="form-container">
                <div class="docs-container">
                    <div class="docs-table-wrapper">
                        <table class="docs-table">
                            <thead>
                                <tr>
                                    <th>Norma/Manual</th>
                                    <th>Libro</th>
                                    <th>Tema</th>
                                    <th>Parte</th>
                                    <th></th>
                                    <th>Título</th>
                                    <th></th>
                                    <th>Capítulo</th>
                                    <th>Designación</th>
                                    <th>Nombre</th>
                                    <th>Origen</th>
                                    <th>Ano Simple</th>
                                    <th>Año</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documentosProcesados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($documento->tipo); ?></td>
                                    <td><?php echo e($documento->libro); ?></td>
                                    <td><?php echo e($documento->tema); ?></td>
                                    <td><?php echo e($documento->parte); ?></td>
                                    
                                    <td><?php echo e($documento->desc_parte); ?></td>
                                    <td><?php echo e($documento->titulo); ?></td>
                                    
                                    <td><?php echo e($documento->desc_titulo); ?></td>
                                    <td><?php echo e($documento->capitulo); ?></td>
                                    <td><?php echo e($documento->designacion ?? '--'); ?></td>
                                    <td><?php echo e($documento->nombre ?? '--'); ?></td>
                                    <td><?php echo e($documento->origen ?? '--'); ?></td>
                                    <td><?php echo e($documento->anio_simple ?? '--'); ?></td>
                                    <td><?php echo e($documento->anio ?? '--'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html><?php /**PATH C:\laragon\www\sitionormasext\resources\views/Inicio.blade.php ENDPATH**/ ?>