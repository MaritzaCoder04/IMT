<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    </head>
    <body>
        <div class="all-form"> 
            <div class="form-container">
                <div class="docs-container">
                    <div class="docs-table-wrapper">
                        <table class="docs-table">
                            <thead>
                                <tr>
                                    <th>Norma/Manual</th>
                                    <th>Libro</th>
                                    <th>Tema</th>
                                    <th>Parte</th>
                                    <th>Título</th>
                                    <th>Capítulo</th>
                                    <th>Designación</th>
                                    <th>Nombre</th>
                                    <th>Origen</th>
                                    <th>Nueva</th>
                                    <th>Actualización</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $documentosProcesados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($documento->tipo == 1 ? 'Manual' : 'Norma'); ?></td>
                    <td><?php echo e($documento->libroRelacion->desc ?? $documento->libro); ?></td>
                    <td><?php echo e($documento->temaRelacion->desc ?? $documento->tema); ?></td>
                    <td><?php echo e($documento->parte); ?></td>
                    <td><?php echo e($documento->titulo); ?></td>
                    <td><?php echo e($documento->capitulo); ?></td>
                    <td><?php echo e($documento->designacion ?? '--'); ?></td>
                    <td><?php echo e($documento->nombre ?? '--'); ?></td>
                    <td><?php echo e($documento->origen ?? '--'); ?></td>
                    <td><?php echo e($documento->fecha_nueva ?? '--'); ?></td>
                    <td><?php echo e($documento->fechas_actualizacion ?? '--'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="11" class="empty-state">
                        <p>No hay documentos registrados</p>
                    </td>
                </tr>
                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html>
<?php /**PATH C:\laragon\www\sitionormasext\resources\views/welcome.blade.php ENDPATH**/ ?>